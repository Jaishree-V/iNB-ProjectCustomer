package com.mindgate.main.repository;

import java.util.List;

import com.mindgate.main.domain.Customer;


public interface CustomerRepositoryInterface {
	public boolean addNewCustomer(Customer customer);
	public Customer updateCustomer(Customer customer);
	public boolean deleteCustomer(String customerId);
	public Customer getCustomerByCustomerId(String string);
	public List<Customer> getAllCustomers();

}
