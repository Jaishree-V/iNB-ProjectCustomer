package com.mindgate.main.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindgate.main.domain.Customer;
import com.mindgate.main.service.CustomerServiceInterface;


@RestController
@RequestMapping("customerapi")
public class CustomerController {

	@Autowired
	private CustomerServiceInterface customerServiceInterface;
	
	@RequestMapping(value= "customers", method = RequestMethod.GET)
	public List<Customer> getAllCustomersList(){	
		List<Customer> customerList =customerServiceInterface.getAllCustomers();
		System.out.println(customerList);
		return customerList;
	}
	@RequestMapping(value = "customers/{customerId}", method = RequestMethod.GET)
	public  Customer getCustomer(@PathVariable String customerId) {
		return customerServiceInterface.getCustomerByCustomerId(customerId);
	}
	@RequestMapping(value = "customers/customer" , method = RequestMethod.POST)
	public boolean addCustomer(@RequestBody Customer customer) {
		return customerServiceInterface.addNewCustomer(customer);
	}
	@RequestMapping(value = "customers/{customerId}", method = RequestMethod.DELETE)
	public  boolean deleteCustomer(@PathVariable String customerId) {
		return customerServiceInterface.deleteCustomer(customerId);
	}
	@RequestMapping(value = "customers/customer" , method = RequestMethod.PUT)
	public Customer updateCustomer(@RequestBody Customer customer) {
		return customerServiceInterface.updateCustomer(customer);
	}
	
}
