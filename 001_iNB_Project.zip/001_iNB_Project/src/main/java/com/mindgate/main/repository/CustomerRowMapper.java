package com.mindgate.main.repository;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.mindgate.main.domain.Customer;

public class CustomerRowMapper implements RowMapper<Customer>{

	@Override
	public Customer mapRow(ResultSet rs, int rowNum) throws SQLException {
		String customerId = rs.getString("customer_id");
		String firstName = rs.getString("first_name");
		String lastName = rs.getString("last_name");
		String userName = rs.getString("username");
		String password = rs.getString("password");
		String addressLine1 = rs.getString("address_line1");
		String addressLine2 = rs.getString("address_line2");
		String addressLine3 = rs.getString("address_line3");
		String city = rs.getString("city");
		String state = rs.getString("state");
		int zip = rs.getInt("zip");
		int phone = rs.getInt("phone");
		int cell = rs.getInt("cell");
		String email = rs.getString("email");
		String customerStatus = rs.getString("customer_status");
		String passwordReachLimit = rs.getString("password_reach_limit");
		
		Customer customer = new Customer(firstName, lastName, userName, password, addressLine1, addressLine2, addressLine3, city, state, zip, phone, cell, email, customerId, customerStatus, passwordReachLimit);		
		return customer;
	}
}
