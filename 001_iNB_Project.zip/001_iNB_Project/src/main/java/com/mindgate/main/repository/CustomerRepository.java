package com.mindgate.main.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mindgate.main.domain.Customer;

@Repository
public class CustomerRepository implements CustomerRepositoryInterface{
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	private final static String INSERT_NEW_CUSTOMER = "insert into customer(first_name,last_name,username,password,address_line1,address_line2,address_line3,city,state,zip,phone,cell,email) values (?,?,?,?,?,?,?,?,?,?,?,?,?)";
	private final static String UPDATE_EXISTING_CUSTOMER = "update customer set first_name=?,last_name=?, password=?,username=?,address_line1=?,address_line2=?,address_line3=?,city=?,state=?,zip=?,phone=?,cell=?,email=? where customer_id=?";
	private final static String DELETE_EXISTING_CUSTOMER = "delete customer where customer_id=?";
	private final static String SELECT_ALL_CUSTOMERS = "select * from customer";
	private final static String SELECT_ONE_CUSTOMER = "select * from customer where customer_id=?";
	
	@Override
	public boolean addNewCustomer(Customer customer) {
		Object[] parameters = {customer.getFirstName(), customer.getLastName(),customer.getUserName(),customer.getPassword(),customer.getAddressLine1(),customer.getAddressLine2(),customer.getAddressLine3(),customer.getCity(),customer.getState(),customer.getZip(),customer.getPhone(),customer.getCell(),customer.getEmail()};
		jdbcTemplate.update(INSERT_NEW_CUSTOMER, parameters);
		return true;
	}

	@Override
	public Customer updateCustomer(Customer customer) {
		Object[] parameters = {customer.getFirstName(), customer.getLastName(),customer.getUserName(),customer.getPassword(),customer.getAddressLine1(),customer.getAddressLine2(),customer.getAddressLine3(),customer.getCity(),customer.getState(),customer.getZip(),customer.getPhone(),customer.getCell(),customer.getEmail(),customer.getCustomerId()};
		int rowCount = jdbcTemplate.update(UPDATE_EXISTING_CUSTOMER, parameters);
		if (rowCount > 0) {
			return getCustomerByCustomerId(customer.getCustomerId());
		}

		return null;
	}

	@Override
	public boolean deleteCustomer(String customerId) {
		int rowCount = jdbcTemplate.update(DELETE_EXISTING_CUSTOMER, customerId);
		if (rowCount > 0) {
			return true;
		} else
			return false;
	}

	@Override
	public Customer getCustomerByCustomerId(String customerId) {
		CustomerRowMapper customerRowMapper = new CustomerRowMapper();
		Customer customer = jdbcTemplate.queryForObject(SELECT_ONE_CUSTOMER, customerRowMapper, customerId);
		return customer;
	}

	@Override
	public List<Customer> getAllCustomers() {
		
		CustomerRowMapper customerRowMapper = new CustomerRowMapper();
		System.out.println(jdbcTemplate.query(SELECT_ALL_CUSTOMERS, customerRowMapper));
		return jdbcTemplate.query(SELECT_ALL_CUSTOMERS, customerRowMapper);
	}

	
}
