/**
 * 
 */
package com.mindgate.main.service;

import java.util.List;

import com.mindgate.main.domain.Customer;
import com.mindgate.main.repository.CustomerRepositoryInterface;

public interface CustomerServiceInterface extends CustomerRepositoryInterface {
	public boolean addNewCustomer(Customer customer);
	public Customer updateCustomer(Customer customer);
	public boolean deleteCustomer(String customerId);
	public Customer getCustomerByCustomerId(String customerId);
	public List<Customer> getAllCustomers();
}
